#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>


void TwosComplement(const int input[8], int output[8])
{
	int temp;
	int carry = 1;
	for(int i = 0; i < 8; i++)
	{
		temp = (input[i] == 1 ? 0 : 1) + carry; // Inverts the bit and carries the added one if needed
		if (temp == 2)
		{
		    temp = 0; // Resets a bit value of two to zero and continues carrying the one.
		}
		else
		{
		    carry = 0; // Gets rid of the carry if the bit value isn't 2.
		}
		output[i] = temp;
	}
}

float Bin2Dec(const float x, int bin[8]){
	float preDivision = 0;
	int neg = 1;
	int twoTracker = 1;
	int tempBin[8] = {0, 0, 0, 0, 0, 0, 0, 0};

	// Recognizes a negative number
	if (bin[7] == 1)
	{
		// Makes the Two's Complemented binary positive again for conversion
		TwosComplement(bin, tempBin);
		neg = -1;
	}
	else 
	{
		// Compies tempBin from bin, something that happens in TwosComplement()
	    for(int i = 0; i < 8; i++)
	    {
	       tempBin[i] = bin[i];
	    }
	}
	for (int i = 0; i < 8; i++)
	{
		// Adds up the values of each bit
		preDivision += tempBin[i] * twoTracker;
		twoTracker *= 2;
	}

	// Returns a negative decimal after division
	return (float) preDivision / 128.0 * neg;
}

void Dec2Bin(const float x, int bin[8]){
	// Keeps track of negative nature
	int neg = (x < 0 ? -1 : 1);

	// Multiply by 128 (and possibly -1) to make the range between 0 and 127
    float toRound = x * neg * 128;

    // Round the decimal
    int num = ((toRound - (int)toRound) > 0.5 ? (int)toRound + 1: (int)toRound);
    int testBin[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    
    // Convert to binary
    for (int i = 0; i < 8; i++)
    {
        testBin[i] = num % 2;
        bin[i] = testBin[i];
        num = num / 2;
    }
    
    // Convert to Two's Complement if neg
    if(neg < 0){
        TwosComplement(testBin, bin);
    }
}