/* Soren Madsen
 * Lab 4
 * 20 May 2018
 * Implements an ADT, LIST, using a ciruclar doubly linked list of generic types
 * and functions to manipulate the LIST.
*/
# include <stdio.h>
# include <stdlib.h>
# include <assert.h>
# include <stdbool.h>
# include "list.h"

struct list{
  int count;
  struct node *head;
  int (*compare)();
};

struct node{
  void *data;
  struct node *next;
  struct node *prev;
};

 // Create LIST
 // Allocates memory for a LIST and initiaizes the sentinel node.
 // Complexity: O(1)

LIST *createList(int (*compare)()){
  LIST *lp;
  lp = malloc(sizeof(LIST));
  assert(lp != NULL);

  lp->compare = compare;

  struct node *hp;
  hp = malloc(sizeof(struct node));
  assert(hp != NULL);
  hp->data = NULL;
  hp->next = hp;
  hp->prev = hp;

  lp->head = hp;

  return lp;
}

 // Destroy LIST
 // Frees the memory allocated for the LIST.
 // Complexity: O(n)

void destroyList(LIST *lp){
  assert(lp != NULL);
  struct node *pDel;
  pDel = lp->head->next;                // Skips over lp->head because it doesn't need to be freed yet

  struct node *pNext = pDel;            // Compiler warned that I should initialize the pointer of pNext
  while (pNext != lp->head){            // Using NULL meant that the while loop condition was not met
    pNext = pDel->next;
    free(pDel);
    pDel = pNext;
  }
  free(lp);
}

 // Number of Items
 // Returns how many items are in the LIST.
 // Complexity: O(1)

int numItems(LIST *lp){
  assert(lp != NULL);
  return lp->count;
}

 // Add First
 // Adds an item to the beginning of the LIST.
 // Complexity: O(1)

void addFirst(LIST *lp, void *item){
  assert(lp != NULL && item != NULL);
  struct node *toAdd;
  toAdd = malloc(sizeof(struct node));
  toAdd->data = item;

  lp->head->next->prev = toAdd;
  toAdd->next = lp->head->next;
  toAdd->prev = lp->head;
  lp->head->next = toAdd;

  lp->count++;
}

 // Add Last
 // Adds an item to the end of the LIST.
 // Complexity: O(1)

void addLast(LIST *lp, void *item){
  assert(lp != NULL && item != NULL);
  struct node *toAdd;
  toAdd = malloc(sizeof(struct node));
  toAdd->data = item;

  lp->head->prev->next = toAdd;
  toAdd->next = lp->head;
  toAdd->prev = lp->head->prev;
  lp->head->prev = toAdd;

  lp->count++;
}

 // Remove First
 // Removes and returns an item from the beginning of the LIST.
 // Complexity: O(1)

void *removeFirst(LIST *lp){
  assert(lp != NULL && lp->count > 0);
  struct node *pTarg;
  pTarg = lp->head->next;
  void *data = pTarg->data;

  lp->head->next = pTarg->next;
  pTarg->next->prev = lp->head;

  free(pTarg);
  lp->count--;
  return data;
}

 // Remove Last
 // Removes and returns an item from the end of the LIST.
 // Complexity: O(1)

void *removeLast(LIST *lp){
  assert(lp != NULL && lp->count > 0);
  struct node *pTarg;
  pTarg = lp->head->prev;
  void *data = pTarg->data;

  lp->head->prev = pTarg->prev;
  pTarg->prev->next = lp->head;

  free(pTarg);
  lp->count--;
  return data;
}

 // Get First
 // Returns an item from the beginning of the LIST.
 // Complexity: O(1)

void *getFirst(LIST *lp){
  assert(lp != NULL);
  return lp->head->next->data;
}

 // Get Last
 // Returns an item from the end of the LIST.
 // Complexity: O(1)

void *getLast(LIST *lp){
  assert(lp != NULL);
  return lp->head->prev->data;
}

 // Remove Item
 // Removes an item from the LIST, if it is contained in the LIST.
 // Complexity: O(n)

void removeItem(LIST *lp, void *item){
  assert(lp != NULL && item != NULL);
  struct node *pTarg;

  pTarg = lp->head->next;
  while(pTarg != lp->head){
    if((*lp->compare)(pTarg->data, item) == 0){
      pTarg->prev->next = pTarg->next;
      pTarg->next->prev = pTarg->prev;
      free(pTarg);
      return;
    }
    pTarg = pTarg->next;
  }
  return;
}

 // Find Item
 // Finds an item and returns it if it is found.
 // Complexity: O(n)

void *findItem(LIST *lp, void *item){
  assert(lp != NULL && item != NULL);
  struct node *pTarg;
  struct node *pHelp;

  pTarg = lp->head->next;
  while(pTarg != lp->head){
    if((*lp->compare)(pTarg->data, item) == 0){
      return pTarg->data;
    }
    pHelp = pTarg->next;
    pTarg = pHelp;
  }
  return NULL;
}

 // Get Items
 // Returns an array of all the items in the LIST.
 // Complexity: O(n)

void *getItems(LIST *lp){
  assert(lp != NULL);
  void **list;
  int track = 0;
  list = malloc(sizeof(void *) * lp->count);
  struct node *pTarg;

  pTarg = lp->head->next;
  while(pTarg != lp->head){
    list[track] = pTarg->data;
    pTarg = pTarg->next;
    track++;
  }
  return list;
}
