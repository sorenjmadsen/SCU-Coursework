/* Soren Madsen
 * Lab 4
 * 20 May 2018
 * Implements an ADT, SET, using a hash table implemented with
 * circular doubly linked LISTs of generic types and functions.
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>
#include <string.h>
#include "set.h"
#include "list.h"

#define AVG_CHAIN_LENGTH  20

struct set{
    int count;
    int length;
    LIST** lists;
    int (*compare)();
    unsigned (*hash)();
};

 // Create Set
 // Big O of O(n)
 // Creates a set by initializing the variables and allocating memory
 // for those variables defined in the struct and returns the new SET.

SET *createSet(int maxElts, int (*compare)(), unsigned (*hash)()){
    SET *sp;
    sp = malloc(sizeof(SET));
    assert(sp != NULL);
    sp->count = 0;
    sp->length = maxElts / AVG_CHAIN_LENGTH;
    sp->lists = malloc(sizeof(LIST *) * sp->length);
    sp->compare = compare;
    sp->hash = hash;
    assert(sp->lists != NULL);
    for(int i = 0; i < sp->length; i++){
      sp->lists[i] = createList(sp->compare);
    }
    return sp;
}

// Destroy Set
// Big O of O(n)
// Destroys the set passed through by freeing the allocated memory.

void destroySet(SET *sp){
    assert(sp != NULL);
    assert(sp->lists != NULL);
    for(int i = 0; i < sp->length; i++){
        //destroyList(sp->lists[i]);
    }
    free(sp->lists);
    free(sp);
}

// Number of Elements
// Big O of O(1)
// Returns the number of elements of sp.

int numElements(SET *sp){
    assert(sp != NULL);
    return sp->count;
}

// Add Element
// Expected Big O of O(1), Worst Case Big O of O(n)
// Adds an element to the hash table's LIST, if it does not already exist.

void addElement(SET *sp, void *elt){
    assert(sp != NULL && elt != NULL);
    int index = (*sp->hash)(elt) % sp->length;
    if(findItem(sp->lists[index], elt)) return;
    addLast(sp->lists[index], elt);
    sp->count++;
}

// Remove Element
// Expected Big O of O(1), Worst Case Big O of O(n)
// Removes an element from the hash table's LIST if it is found.

void removeElement(SET *sp, void *elt){
    assert(sp != NULL && elt != NULL);
    int index = (*sp->hash)(elt) % sp->length;
    if(findItem(sp->lists[index], elt)){
      removeItem(sp->lists[index], elt);
      sp->count--;
    }
}

 // Find Element
 // Expected Big O of O(1), Worst Case Big O of O(n)
 // Finds and returns an element if found in the hash table

void *findElement(SET *sp, void *elt){
    assert(sp != NULL && elt != NULL);
    int index = (*sp->hash)(elt) % sp->length;
    return findItem(sp->lists[index], elt);
}

 // Get Elements
 // Big O of O(n)
 // Returns the elements of the SET in a newly allocated array

void *getElements(SET *sp){
    void **copy;
    int i, j = 0;
    assert(sp != NULL);
    copy = malloc(sizeof(void*) * sp->count);
    assert(copy != NULL);
    for(i=0; i < sp->length; i++){
    	 memcpy(copy + j, getItems(sp->lists[i]), sizeof(void *) * numItems(sp->lists[i]));
       j += numItems(sp->lists[i]);
    }
    return copy;
}
