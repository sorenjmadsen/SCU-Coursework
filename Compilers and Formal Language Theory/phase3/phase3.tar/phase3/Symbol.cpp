#include "Symbol.h"
Symbol::Symbol(const std::string &name, const Type &type)
    : _name(name), _type(type){}