int putchar();

int main(void)
{
    putchar(83);
    putchar(101);
    putchar(103);
    putchar(109);
    putchar(101);
    putchar(110);
    putchar(116);
    putchar(97);
    putchar(116);
    putchar(105);
    putchar(111);
    putchar(110);
    putchar(32);
    putchar(102);
    putchar(97);
    putchar(117);
    putchar(108);
    putchar(116);
    putchar(10);
}
